

//pascalCasing
function Message(){
    //jsx javascript xmll
    const name ='nishu';
    if(name)
      return<h1>hello {name} </h1>;
    return<h1>hello wrold</h1> ; 


}
export default Message;